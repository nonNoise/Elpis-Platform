# -*- coding: utf-8 -*-
import httplib, urllib
import time
import ElpisDB
import ElpisXML
import datetime
import time
import os.path
import sys 


#_URL_ = "kitagami.org:1234"
_URL_ = "localhost:1234"
_POST_ = "/ArmRobotAPI2/"


argvs = sys.argv  
argc = len(argvs)
print argvs
print argvs[0]
print argc
if (argc != 2): 
    print 'Usage: # python %s filename' % argvs[0]
    quit()
print argvs[1]



cnt = 0
while 1 :
	armtime = raw_input('Time?:')
	arm = raw_input('arm?:')

	postlist = {
				"hw_did":"5678",
				"service_name":"POST_TESTER",
				"api_ver":"01",
				"arm":"10",
				"armtime":"3"
		 }	
	
	cnt = cnt + 1

	params = urllib.urlencode( postlist ) 
	print params	
	headers = {"Content-type": "application/x-www-form-urlencoded","Accept": "text/plain"}
	conn = httplib.HTTPConnection( _URL_ )
	#conn = httplib.HTTPConnection("localhost:1234")
	conn.request("POST", _POST_, params, headers)
	response = conn.getresponse()
	print response.status, response.reason
	data = response.read()
	print data
	time.sleep(2)

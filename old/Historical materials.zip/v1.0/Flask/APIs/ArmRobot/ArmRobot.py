# -*- coding: utf-8 -*-
from flask import Module, render_template
from flask import Flask, make_response,request,abort, redirect, url_for
import pymongo  
import json

import datetime
import time
import os.path
app = Module(__name__)

##****************************************************************************************##
##	Arduino Post																			##
##****************************************************************************************##

@app.route('', methods=['POST','GET'])

def ArmRobot():
	##======================================##
	## Configuration Block					##
	##======================================##
	##-- Config Data Lode.
	import ArmRobot_config
	Elpis = ArmRobot_config.Conf()	
	##-- MangoDB Connect and Lord
	con = pymongo.Connection()
	db = con['ElpisDB']
	##======================================##
	## Auto Run Input Block					##
	##======================================##
	##-- DB input Block
	if request.method == 'POST':
		DBdata = db["ID_" + request.form["hw_did"] + "_INPUT"]
		for slist in Elpis.POST:
			Elpis.POST[slist] = request.form[slist]
	else :	
		DBdata = db["ID_" + request.values["hw_did"]]
		for slist in Elpis.POST:
			Elpis.POST[slist] = request.values[slist]

	deta = datetime.datetime.today()
	dtime = deta.strftime("%H:%M:%S")
	dday = deta.strftime("%Y/%m/%d")	
	Elpis.data["day"] =dtime
	Elpis.data["time"] =dday
	Elpis.data["ipaddr"] = request.remote_addr

	##-- DB insert Block
	Elpis.POST.update(Elpis.data)
	#DBdata.remove()		
	DBdata.insert(Elpis.POST)	

	try:
		DBdata = db["ID_" + request.form["hw_did"] + "_OUTPUT"]
		dic = DBdata.find().sort("_id",-1).limit(1)[0]
		DBdata.remove()		
		del dic["_id"]	
	except:
		dic = {}
	#print json.dumps(dic) 
	return json.dumps(dic) 

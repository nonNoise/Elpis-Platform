# -*- coding: utf-8 -*-
from flask import Module, render_template
from flask import Flask, make_response,request,abort, redirect, url_for
import ElpisDB
import ElpisXML
import datetime
import time
import os.path
app = Module(__name__)

##****************************************************************************************##
##	Arduino Post																			##
##****************************************************************************************##
@app.route('/', methods=['POST','GET'])
def ArmRobot_API():
	##======================================##
	## Configuration Block					##
	##======================================##
	print os.getcwd()
	xmlfile =  os.getcwd() + "/configXML/ArmRobot_API.xml"
	inxml = ElpisXML.ElpisXML(xmlfile)
	#print inxml
	#inxml.AllRead()
	xmlpost = inxml.GetElement("POST")
	formlist = inxml.GetAttribute(xmlpost,"REQUEST","form")  
	##======================================##
	## Auto Run Block						##
	##======================================##
	if request.method == 'POST':
		for slist in formlist:
			print slist + " ",
			print request.form[slist]
		dbfile = "DB/" + request.form['service_name'] + "_"+ request.form['hw_did'] + ".db"
		db = ElpisDB.ElpisDB(dbfile)
		db.New_DB(xmlfile)
		##--Debug Mode--##	
		#db.Remove_DB("Input")
	else :
		for slist in formlist:
			print slist + " ",
			print request.values[slist]
		dbfile = "DB/" + request.values['service_name'] + "_"+ request.values['hw_did'] + ".db"
		db = ElpisDB.ElpisDB(dbfile)
		db.New_DB(xmlfile)
		##--Debug Mode--##	
		#db.Remove_DB("Input")

	##======================================##
	## Fixed data Block						##
	##======================================##
	s = db.Get_Table()
	deta = datetime.datetime.today()
	dtime = deta.strftime("%H:%M:%S")
	dday = deta.strftime("%Y/%m/%d")
	str = ""
	data = ""
	str = db.strmix(str, "day")
	data = db.strmix(data, dday)
	str = db.strmix(str, "time")
	data = db.strmix(data, dtime)
	str = db.strmix(str, "ipaddr")
	data = db.strmix(data, request.remote_addr)
	##======================================##
	## Auto Run Block						##
	##======================================##
	if request.method == 'POST':
		for slist in formlist:
			str = db.strmix(str, slist)
			data = db.strmix(data, request.form[slist])
	else :
		for slist in formlist:
			str = db.strmix(str, slist)
			data = db.strmix(data, request.values[slist])

	str = str.rstrip(",") 
	data = data.rstrip(",")         
	print str
	print data
	db.Set_Column("Input",str, data)
	db.Commit()
	print "================"
	##======================================##
	## OutPut Block							##
	##======================================##
	dblistEle = inxml.GetElement("ElpisDB")
	dblistEle2 = inxml.GetElement2(dblistEle,"Output")
	dblist = inxml.GetAttribute(dblistEle2 ,"DB","name")  

	db.Close()


	return  "OK"

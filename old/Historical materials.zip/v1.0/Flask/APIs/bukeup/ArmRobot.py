# -*- coding: utf-8 -*-
from flask import Module, render_template
from flask import Flask, make_response,request,abort, redirect, url_for
import ElpisDB
import ElpisXML
import datetime
import time
import os.path
app = Module(__name__)

##****************************************************************************************##
##	Arduino Post																			##
##****************************************************************************************##
@app.route('/', methods=['POST','GET'])
def ArmRobot():
	##======================================##
	## Configuration Block					##
	##======================================##
	print os.getcwd()
	xmlfile =  os.getcwd() + "/configXML/ArmRobot.xml"
	inxml = ElpisXML.ElpisXML(xmlfile)
	#print inxml
	#inxml.AllRead()
	xmlpost = inxml.GetElement("POST")
	formlist = inxml.GetAttribute(xmlpost,"REQUEST","form")  
	##======================================##
	## Auto Run Block						##
	##======================================##
	for slist in formlist:
		print slist + " ",
		print request.form[slist]
	dbfile = "DB/" + request.form['service_name'] + "_"+ request.form['hw_did'] + ".db"
	db = ElpisDB.ElpisDB(dbfile)
	db.New_DB(xmlfile)
	##--Debug Mode--##	
	db.Remove_DB("Input")

	##======================================##
	## Fixed data Block						##
	##======================================##
	s = db.Get_Table()
	deta = datetime.datetime.today()
	dtime = deta.strftime("%H:%M:%S")
	dday = deta.strftime("%Y/%m/%d")
	str = ""
	data = ""
	str = db.strmix(str, "day")
	data = db.strmix(data, dday)
	str = db.strmix(str, "time")
	data = db.strmix(data, dtime)
	str = db.strmix(str, "ipaddr")
	data = db.strmix(data, request.remote_addr)
	##======================================##
	## Auto Run Block						##
	##======================================##
	for slist in formlist:
		str = db.strmix(str, slist)
		data = db.strmix(data, request.form[slist])
	str = str.rstrip(",") 
	data = data.rstrip(",")         
	#print str
	#print data
	db.Set_Column("Input",str, data)
	db.Commit()
	print "================"
	##======================================##
	## OutPut Block							##
	##======================================##
	dblistEle = inxml.GetElement("ElpisDB")
	dblistEle2 = inxml.GetElement2(dblistEle,"Output")
	dblist = inxml.GetAttribute(dblistEle2 ,"DB","name") 
	tlist = ""
	for i in dblist:
		tlist = tlist + i + ","
	tlist = tlist.rstrip(",") 
	tdata = db.Get_NewColumn("Output",tlist)
	print tlist 
	print tdata
	db.Close()
	#print tmp
	strout = ""
	try:
		for i in range(len(dblist)):
			strout = strout + dblist[i] + ":" +tdata[i] + "\n"
	except:
		for i in range(len(dblist)):
			strout = strout + dblist[i] + ":" + "0" + "\n"
	
	return  strout

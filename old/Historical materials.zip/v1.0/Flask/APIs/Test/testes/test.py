import pymongo  

con = pymongo.Connection()
db = con['ElpisDB']
print db
db.ID.insert({"A":"123"})
db.ID.find()
for i in db.ID.find():
	print " " ,	    
	print i

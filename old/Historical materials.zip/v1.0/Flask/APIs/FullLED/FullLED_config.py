# -*- coding: utf-8 -*-

##======================================##
## Configuration Block					##
##======================================##
class Conf:
	def __init__(self):
	## >>-------------------------------<< ##
		self.data = {
			"hello":"World",
			"day":"",
			"time":"",
			"ipaddr":"",
		}
	## >>-------------------------------<< ##
		self.POST = {
			"service_name":"",
			"hw_did":"",
			"state" :"",
		}


# -*- coding: utf-8 -*-
from flask import Flask, make_response,request,abort, redirect, url_for, make_response
import pymongo
import json  
import datetime
import time

app = Flask(__name__)

#_URL_ = "kitagami.org"
_URL_ = "localhost"
_PORT_ = 1234

from APIs import root
app.register_module(root.app, url_prefix="/")
from APIs import arduino_post
app.register_module(root.app, url_prefix="/arduino_post")


from APIs.ArmRobot import ArmRobot
from APIs.ArmRobot import ArmRobot_API
app.register_module(ArmRobot.app, url_prefix="/ArmRobot")
app.register_module(ArmRobot_API.app, url_prefix="/ArmRobot/api")


from APIs.FullLED import FullLED
from APIs.FullLED import FullLED_API
app.register_module(FullLED.app, url_prefix="/FullLED")
app.register_module(FullLED_API.app, url_prefix="/FullLED/api")


from APIs.Test import TestAPI
app.register_module(TestAPI.app, url_prefix="/TestAPI")
from APIs.Test import Test
app.register_module(Test.app, url_prefix="/Test")



if __name__ == '__main__':
	app.debug = True
	app.run(host=_URL_,port=_PORT_)


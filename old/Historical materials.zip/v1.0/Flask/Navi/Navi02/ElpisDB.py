# -*- coding: utf-8 -*-
import sqlite3
from xml.etree import ElementTree

class ElpisDB:
	#=============================#
	def __init__(self, dbfile):
		#print self.root.tag
		self.con = sqlite3.connect(dbfile)
		
	#def Chake_DB(self):
	
	#=============================#
	def New_DB(self , xmlfile):
		#print self.root.find("SQLiteDB").tag
		self.xmlfp = open(xmlfile,"r")
		self.tree = ElementTree.parse(self.xmlfp)
		self.root = self.tree.getroot()
		s = self.root.find("ElpisDB")
		for node in s:
			n = node.tag
			#print '=========='
			##print "create table %s(" % n
			str = "create table %s (" % n
			for node2 in s.findall(n+'/DB' ):
				name = node2.attrib.get('name')
				#print name ,
				typ = node2.attrib.get('type')
				#print typ
				##print name + " " + typ + ","
				str = str + name + " " + typ + ","
			##print ");"	
			str = str.rstrip(',')
			str = str +  ");"
			#print str
			try:
				self.con.execute(str)
			except Exception, ex:
			#	self.con.execute("delete from %s" % n )
				self.con.commit()
		
	#=============================#
	def Remove_DB(self,table):
		self.con.execute("delete from %s" % table )
		self.con.commit()
	
	
	#=============================#
	def Get_Table(self):
		c = self.con.execute("select name from sqlite_master where type='table'")
		#print c
		
		i = 0
		s = []
		for a in c:
			#print a[0]
			s.append(a[0])
		return s
	
	#=============================#
	def Set_Column(self,table,column,val):
		#print "insert into %s ( %s ) values( %s );" % (table , column , val )
		self.con.execute( "insert into %s ( %s ) values( %s );" % (table , column , val ))
	#=============================#
	def Get_Column(self,table,column):
		#print "insert into %s ( %s ) values( %s );" % (table , column , val )
		return self.con.execute( "select %s from %s ;" % ( column , table))
	#=============================#
	def Get_NewColumn(self,table,column):
		#print "insert into %s ( %s ) values( %s );" % (table , column , val )
		c = self.con.execute( "select %s from %s ;" % ( column , table))
		r = c.fetchone()
		#print r
		try:
			return r
		except:
			return 'None'
	#=============================#
	def Commit(self):
		self.con.commit()
	
	#=============================#
	def Close(self):
		self.con.commit()
		self.con.close()
		self.xmlfp.close()
	#=============================#
	def strmix(self,str,mix):
		str = str + "\"" + mix +  "\"" + ","
		return str

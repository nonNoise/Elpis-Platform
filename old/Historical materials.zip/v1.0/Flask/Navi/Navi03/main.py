# -*- coding: utf-8 -*-
import pymongo  
import json
import datetime
import time
import sys 




import Navi_config
Navi = Navi_config.Conf()	

con = pymongo.Connection()
db = con[Navi.init['dbname']]

Input_1 = db[Navi.init['service_1']+"_INPUT"]
Input_2 = db[Navi.init['service_2']+"_INPUT"]
Output_1 = db[Navi.init['service_1']+"_OUTPUT"]
Output_2 = db[Navi.init['service_2']+"_OUTPUT"]

while 1:
	Navi = Navi_config.Conf()	
	for slist in Navi.sv1_to_sv2:
		try:
			Navi.sv1_to_sv2[slist] = Input_1.find().sort("_id",-1).limit(1)[0][slist]
			print slist + ":"  + Navi.sv1_to_sv2[slist]
		except:
			Navi.sv1_to_sv2[slist] = ""
	Output_2.insert(Navi.sv1_to_sv2)	
	Input_1.remove()
		
	print "---------------------------------"
	for slist in Navi.sv2_to_sv1 :
		try:
			Navi.sv2_to_sv1 [slist] = Input_2.find().sort("_id",-1).limit(1)[0][slist]
			print slist + ":"  + Navi.sv2_to_sv1[slist]
		except:
			Navi.sv2_to_sv1 [slist] = ""

	Output_1.insert(Navi.sv2_to_sv1 )	
	Input_2.remove()
	time.sleep(0.1)
	print "---------------------------------"
	#print Navi.InToOut[slist]

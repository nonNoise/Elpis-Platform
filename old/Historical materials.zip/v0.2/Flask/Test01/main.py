# -*- coding: utf-8 -*-
import ElpisDB
import datetime
import time

import sys 
argvs = sys.argv  
argc = len(argvs)

print argvs
print argvs[0]
print argc
if (argc != 2): 
    print 'Usage: # python %s filename' % argvs[0]
    quit()
print argvs[1]

while 1:
	db = ElpisDB.ElpisDB("../DB/" + argvs[1] + ".db")
	db.New_DB()
	#db.Remove_DB("WriteTB")
	deta = datetime.datetime.today()
	dtime = deta.strftime("%H:%M:%S")
	dday = deta.strftime("%Y/%m/%d")

	str = ""
	data = ""
	
	str = db.strmix(str, "write")
	data = db.strmix(data, dtime)
	str = str.rstrip(",") 
	data = data.rstrip(",") 
	
	print str
	print data
	
	db.Remove_DB("WriteTB")
	db.Set_Column("WriteTB",str, data)
	db.Commit()
	print "================"
	db.Close()
	
	time.sleep(1)

# -*- coding: utf-8 -*-
from flask import Flask, make_response,request
import ElpisDB
import datetime
import time

app = Flask(__name__)

#_URL_ = "kitagami.org"
_URL_ = "localhost"
_PORT_ = 1234




@app.route('/post', methods=['POST'])
def post():
	print request.form['pro_ver']
	print request.form['pro_subver']
	print request.form['hw_sid']
	print request.form['hw_did']
	print request.form['hw_ver']
	print request.form['hw_fmver']
	print request.form['sv_name']
	print request.form['sv_id']
	print request.form['cm_com']
	print request.form['cm_date']

	db = ElpisDB.ElpisDB("DB/" + request.form['hw_did'] + ".db")
	db.New_DB()
	#db.Remove_DB("ElpisDB")
	s = db.Get_Table()
	deta = datetime.datetime.today()
	dtime = deta.strftime("%H:%M:%S")
	dday = deta.strftime("%Y/%m/%d")

	str = ""
	data = ""
	
	str = db.strmix(str, "day")
	data = db.strmix(data, dday)
	str = db.strmix(str, "time")
	data = db.strmix(data, dtime)
	str = db.strmix(str, "ipaddr")
	data = db.strmix(data, "192.168.0.2")
	str = db.strmix(str, "pro_ver")
	data = db.strmix(data, request.form['pro_ver'])
	str = db.strmix(str, "pro_subver")
	data = db.strmix(data, request.form['pro_subver'])
	str = db.strmix(str, "hw_sid")
	data = db.strmix(data, request.form['hw_sid'])
	str = db.strmix(str, "hw_did")
	data = db.strmix(data, request.form['hw_did'])
	str = db.strmix(str, "hw_ver")
	data = db.strmix(data, request.form['hw_ver'])
	str = db.strmix(str, "hw_fmver")
	data = db.strmix(data, request.form['hw_fmver'])
	str = db.strmix(str, "sv_name")
	data = db.strmix(data, request.form['sv_name'])
	str = db.strmix(str, "sv_id")
	data = db.strmix(data, request.form['sv_id'])
	str = db.strmix(str, "cm_com")
	data = db.strmix(data, request.form['cm_com'])
	str = db.strmix(str, "cm_date")
	data = db.strmix(data, request.form['cm_date'])
	str = str.rstrip(",") 
	data = data.rstrip(",") 
	
	print str
	print data
	
	db.Set_Column("Input",str, data)
	db.Commit()
	print "================"
	
	try:
		#print db.Get_Column("WriteTB","write") 
		for a in db.Get_Column("Output","write") :
			print a[0]
		tmp = a[0] #"HELLO" #E.read("write")
	except:
		tmp = "HELLO"
	
	db.Close()
	dtime = datetime.datetime.today()

	#twstr = u"HELLO World! #mtf2012"
	#status = api.PostUpdate(twstr)
	str = "+++\r\n" \
		"%s\r\n"  \
		"\r\n" \
		"+++\r\n" % tmp
	return str



if __name__ == '__main__':
	app.debug = True
	app.run(host=_URL_,port=_PORT_)

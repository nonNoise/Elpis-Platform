# -*- coding: utf-8 -*-
from flask import Module, render_template, make_response,url_for,request
import json
app = Module(__name__)


@app.route("")
def login():

	f = open("./APIs/json/login.json")
	data = json.load("{\"login\":\"hello\",}")
	f.close()
	print(data)


	name = request.cookies.get('Elpis')
	print name	
	response = make_response(render_template('login.html', name = name))
	#response.headers.add('Cache-Control', 'no-store, no-cache, must-revalidate, post-check=0, pre-check=0')
	#response.set_cookie('Elpis', 'Elpis username')
	response.set_cookie('Elpis',value='Hello')
	#response.cache_control.no_cache = False
	return response


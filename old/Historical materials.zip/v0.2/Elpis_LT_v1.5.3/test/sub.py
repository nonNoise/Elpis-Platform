# -*- coding: utf-8 -*-

import time
import sys

#while 1:
for i in range(20):
	#print u"お帰りなさい、ご主人様.　現在の数は[%d]です。" % i 
	print ("あ[%d]" % i )
	#sys.stdout.flush()
	time.sleep(0.1)

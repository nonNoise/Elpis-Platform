# -*- coding: utf-8 -*-
import subprocess
import os

d=  os.path.abspath(os.path.dirname(__file__)) 

#com = ["python",d+"/sub.py"]
com = ["ls"]
p = subprocess.Popen(com,stdout=subprocess.PIPE, stderr=subprocess.PIPE)
p2 = subprocess.Popen(["python",d+"/sub.py"],stdout=subprocess.PIPE, stderr=subprocess.PIPE)

print (p.pid)
#print p2.pid

#print p2.stdout.readline()
for i in range(2):
	print ("-" *10)
	print (p.stdout.readline() )
	#p.stdout.flush()
	#print p2.stdout.read()
print ("-" *10)



	#print p.stdout.flush()
#print p.communicate()

if( p.returncode == None):
	p.kill()
	print ("!! MAIN Kill !!")




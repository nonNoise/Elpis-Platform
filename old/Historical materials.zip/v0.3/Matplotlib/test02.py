# -*- coding: utf-8 -*-
import matplotlib.pyplot as plt
import matplotlib.dates as mdates

import csv
import numpy as np

csvfile = '1234.csv'

f1 = file(csvfile, 'r')
reader = csv.reader(f1)

print reader
nrow = [' ',' ',' ']*10
data = []
time = []
i = 0
j = 0	
sumd = 0.00
for row in reader:
	nrow[i] = row	
	#print j
	data.append(float(nrow[i][4]))
	time.append(nrow[i][0])
	j = j+1
print data[0:10]
print time[0:10]
print len(data)
print len(time)
print type(data[0])
x = np.arange(len(data))
print x
w = np.ones(10000)/10000.0
print w
ave = np.convolve(data,w,'same')
print ave

	
plt.gca().xaxis.set_major_formatter(mdates.DateFormatter('%m/%d/%Y'))
plt.gca().xaxis.set_major_locator(mdates.DayLocator())
plt.plot(time,ave)
#plt.title(u'Check room temperature (testing mode)')
plt.savefig('test2.png')


# -*- coding: utf-8 -*-
import matplotlib.pyplot as plt
import csv
csvfile = '1234.csv'

f1 = file(csvfile, 'r')
reader = csv.reader(f1)

print reader
nrow = [' ',' ',' ']*10
data = []
time = []
i = 0
j = 0	
sumd = 0.00
for row in reader:
	nrow[i] = row	
	print j
	if j%200 == 0 :
		sumd = sumd + float(nrow[i][4])
		print sumd/200
		data.append(sumd/200)
		sumd = 0
		time.append(j)
	else :
		sumd = sumd + float(nrow[i][4])
	j = j+1
print data[0:10]
print time[0:10]
print len(data)
print len(time)

plt.plot(time[0:7000],data[0:7000])
#plt.title(u'Check room temperature (testing mode)')
plt.savefig('test1.png')

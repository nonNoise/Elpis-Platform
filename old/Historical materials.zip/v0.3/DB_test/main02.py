# -*- coding: utf-8 -*-
import sqlite3
from xml.etree import ElementTree
import ElpisDB
import datetime
import time

db = ElpisDB.ElpisDB("t.db")



db.New_DB()

db.Remove_DB("WriteTB")

s = db.Get_Table()

	
#for i in range(10):
while 1:
	deta = datetime.datetime.today()
	dstr = deta.strftime("\"%H:%M:%S\"")
	
	str = ""
	data = ""
	
	str = str + "write"
	data = data + dstr 
	
	db.Set_Column("WriteTB",str, data)
	db.Commit()
	print "================"
	for a in db.Get_Column("WriteTB","write") :
		print a
	
	
	
	
	time.sleep(1)


db.Close()
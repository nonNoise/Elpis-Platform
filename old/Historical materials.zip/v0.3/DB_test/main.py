# -*- coding: utf-8 -*-
import sqlite3
from xml.etree import ElementTree
import ElpisDB
import datetime
import time

db = ElpisDB.ElpisDB("t.db")



db.New_DB()

db.Remove_DB("Input")

s = db.Get_Table()

	
deta = datetime.datetime.today()
dtime = deta.strftime("\"%H:%M:%S\"")
	
for i in range(10):
	db.Set_Column("Input","time", dtime)
	db.Commit()

db.Close()
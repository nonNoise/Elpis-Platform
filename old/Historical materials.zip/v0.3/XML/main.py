# -*- coding: utf-8 -*-
from xml.etree.ElementTree import Element, SubElement, tostring, XML
from xml.etree import ElementTree
from xml.dom import minidom


# Init
f = open("data.xml","r")
tree = ElementTree.parse(f)
elem = tree.getroot()
f.close()

#All Read
for node in elem.iter():
	print node.tag, node.attrib

#Get a Element
testdata = elem.find("TestDATA")
print testdata
dbelem = testdata.find("DB")


#Write a attribute
cnt = 0
for c in testdata:
	c.set('id', str(cnt))
	cnt = cnt +1

#Get a attribute
for e in testdata.getiterator("DB"):
    print e.get("id") ,
    print e.get("data")
 
    
# File Write
f = open("data.xml","w")
tree.write(f,'utf-8')
f.close()

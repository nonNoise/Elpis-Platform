# -*- coding: utf-8 -*-
import ElpisXML

# Init
elpis = ElpisXML.ElpisXML("data.xml")

#All Read
elpis.AllRead()

#Get a Element

testdb = elpis.GetElement("TestDATA")
print testdb

id = ["1","2","3","4","5","6","7","8","9","10","11","12"]

#Write a attribute
elpis.WriteAttribute(testdb,"id",id) 
elpis.WriteAttribute(testdb,"name",id) 

#Get a attribute
print elpis.GetAttribute(testdb,"DB","id") 
    
# File Write
elpis.FileWrite()

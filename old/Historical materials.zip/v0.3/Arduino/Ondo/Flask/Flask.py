#!/usr/bin/env python
# -*- coding: utf-8 -*-
from flask import Flask, render_template , Response , make_response
import time
import serial
app = Flask(__name__)
 
@app.route('/')
def index(name=None):
	#resp = make_response()
	#resp

	response = make_response(render_template('test.html', name=name))
	response.headers.add('Cache-Control', 'no-store, no-cache, must-revalidate, post-check=0, pre-check=0')
	#response.cache_control.no_cache = False
	return response


@app.route('/post', methods=['POST'])
def post():
	return "%s°C" % ser.readline()

@app.route('/get', methods=['GET'])
def get():
	return "%s°C" % ser.readline()
	

if __name__ == '__main__':
	global cnt
	cnt = 0
	tmp_msg = "/dev/tty.usbmodemfa131"
	ser = serial.Serial(tmp_msg)
	ser.baudrate = 115200
	ser.timeout = 1
	print ser.portstr
	time.sleep(1.5)
	app.debug = True
	app.run(host="localhost",port=1234)
 

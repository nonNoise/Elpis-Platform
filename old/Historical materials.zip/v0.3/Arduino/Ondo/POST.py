# -*- coding: utf-8 -*-
import httplib, urllib
import time
import serial


_URL_ = "kitagami.org:1234"
#_URL_ = "localhost:1234"
#tmp_msg = "/dev/tty.usbmodemfa131"
tmp_msg = "/dev/ttyUSB0"
ser = serial.Serial(tmp_msg)
ser.baudrate = 115200
ser.timeout = 5
print ser.portstr
time.sleep(1.5)

while 1 :
	try :
		data = ser.readline().strip("\r\n")
		print "%s°C" % data 
		postdata = {'data': "%s" % data  , 'hw_did':'1234'}
		params = urllib.urlencode(postdata) 
		headers = {"Content-type": "application/x-www-form-urlencoded","Accept": "text/plain"}
		conn = httplib.HTTPConnection( _URL_,timeout=5 )
		conn.request("POST", "/arduino_post", params, headers)
		response = conn.getresponse()
		print response.status, response.reason
		data = response.read()
		print data
		conn.close()
		time.sleep(1)
	except :
		print "Error"
		time.sleep(1)

# -*- coding: utf-8 -*-
from flask import Flask, make_response,request
import ElpisDB
import ElpisXML
import datetime
import time

app = Flask(__name__)

#_URL_ = "kitagami.org"
_URL_ = "localhost"
_PORT_ = 1234

##****************************************************************************************##
##	Arduino Post																			##
##****************************************************************************************##
@app.route('/arduino_post', methods=['POST'])
def arduino_post():
	##======================================##
	## Configuration Block					##
	##======================================##
	xmlfile = "./configXML/arduino_post.xml"
	inxml = ElpisXML.ElpisXML(xmlfile)
	#print inxml
	#inxml.AllRead()
	xmlpost = inxml.GetElement("POST")
	formlist = inxml.GetAttribute(xmlpost,"REQUEST","form") 

	##======================================##
	## Auto Run Block						##
	##======================================##
	for slist in formlist:
		print request.form[slist]
	dbfile = "DB/" + request.form['hw_did'] + ".db"
	db = ElpisDB.ElpisDB(dbfile,xmlfile)
	db.New_DB()
	##--Debug Mode--##	
	#db.Remove_DB("Input")

	##======================================##
	## Fixed data Block						##
	##======================================##
	s = db.Get_Table()
	deta = datetime.datetime.today()
	dtime = deta.strftime("%H:%M:%S")
	dday = deta.strftime("%Y/%m/%d")
	str = ""
	data = ""
	str = db.strmix(str, "day")
	data = db.strmix(data, dday)
	str = db.strmix(str, "time")
	data = db.strmix(data, dtime)
	str = db.strmix(str, "ipaddr")
	data = db.strmix(data, "192.168.0.2")
	##======================================##
	## Auto Run Block						##
	##======================================##
	for slist in formlist:
		str = db.strmix(str, slist)
		data = db.strmix(data, request.form[slist])
	str = str.rstrip(",") 
	data = data.rstrip(",") 
	#print str
	#print data
	db.Set_Column("Input",str, data)
	db.Commit()
	print "================"
	##======================================##
	## OutPut Block							##
	##======================================##
	try:
		for a in db.Get_Column("Output","write") :
			print a[0]
		tmp = a[0] 
	except:
		tmp = ""
	db.Close()
	dtime = datetime.datetime.today()
	str = "+++\r\n" \
		"%s\r\n"  \
		"\r\n" \
		"+++\r\n" % tmp
	return str
##****************************************************************************************##
##	IG Post																			##
##****************************************************************************************##
@app.route('/post', methods=['POST'])
def post():
	##======================================##
	## Configuration Block					##
	##======================================##
	xmlfile = "./configXML/post.xml"
	inxml = ElpisXML.ElpisXML(xmlfile)
	#print inxml
	#inxml.AllRead()
	xmlpost = inxml.GetElement("POST")
	formlist = inxml.GetAttribute(xmlpost,"REQUEST","form") 

	##======================================##
	## Auto Run Block						##
	##======================================##
	for slist in formlist:
		print request.form[slist]
	dbfile = "DB/" + request.form['hw_did'] + ".db"
	db = ElpisDB.ElpisDB(dbfile,xmlfile)
	db.New_DB()
	##--Debug Mode--##	
	#db.Remove_DB("Input")

	##======================================##
	## Fixed data Block						##
	##======================================##
	s = db.Get_Table()
	deta = datetime.datetime.today()
	dtime = deta.strftime("%H:%M:%S")
	dday = deta.strftime("%Y/%m/%d")
	str = ""
	data = ""
	str = db.strmix(str, "day")
	data = db.strmix(data, dday)
	str = db.strmix(str, "time")
	data = db.strmix(data, dtime)
	str = db.strmix(str, "ipaddr")
	data = db.strmix(data, "192.168.0.2")
	##======================================##
	## Auto Run Block						##
	##======================================##
	for slist in formlist:
		str = db.strmix(str, slist)
		data = db.strmix(data, request.form[slist])
	str = str.rstrip(",") 
	data = data.rstrip(",") 
	#print str
	#print data
	db.Set_Column("Input",str, data)
	db.Commit()
	print "================"
	##======================================##
	## OutPut Block							##
	##======================================##
	try:
		for a in db.Get_Column("Output","write") :
			print a[0]
		tmp = a[0] 
	except:
		tmp = ""
	db.Close()
	dtime = datetime.datetime.today()
	str = "+++\r\n" \
		"%s\r\n"  \
		"\r\n" \
		"+++\r\n" % tmp
	return str



if __name__ == '__main__':
	app.debug = True
	app.run(host=_URL_,port=_PORT_)

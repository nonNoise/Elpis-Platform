# -*- coding: utf-8 -*-
from xml.etree.ElementTree import Element, SubElement, tostring, XML
from xml.etree import ElementTree
from xml.dom import minidom

class ElpisXML:
	#=============================#
	def __init__(self, xmlfile):
		self.xmlfile = xmlfile
		f = open(self.xmlfile,"r")
		self.tree = ElementTree.parse(f)
		self.elem = self.tree.getroot()
		f.close()
	#=============================#
	def AllRead(self):
		for node in self.elem.iter():
			print node.tag, node.attrib
	
	#=============================#
	def GetElement(self,tag) :
		return self.elem.find(tag)
	
	#=============================#
	def WriteAttribute(self,elpoint,attr,wlist) :
		i = 0
		for c in elpoint:
			try :
				c.set(attr, wlist[i])
			except :
				c.set(attr, "")
			i = i +1
	#=============================#
	def GetAttribute(self,elepoint,elem,attr) :
		i=0
		list = []
		for e in elepoint.getiterator(elem):
    			list.append(e.get(attr) )
		#print list
		return list
		
	#=============================#
	def FileWrite(self) :
		f = open(self.xmlfile,"w")
		self.tree.write(f,'utf-8')
		f.close()
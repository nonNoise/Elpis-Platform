# -*- coding: utf-8 -*-
import httplib, urllib
import time
import serial

import sys 
argvs = sys.argv  
argc = len(argvs)

print argvs
print argvs[0]
print argc
if (argc != 2): 
    print 'Usage: # python %s filename' % argvs[0]
    quit()
print argvs[1]



cnt = 0
while 1 :
	
	cnt = cnt + 1
	POSTLIST = {	"pro_ver"		:	"1234"	,
				"pro_subver"	:	"2345"	,
				"hw_sid"		:	"3456"	,
				"hw_did"		:	"%s" % argvs[1]	,
				"hw_ver"		:	"5678"	,
				"hw_fmver"	:	"6789"	,
				"sv_name"	:	"7890"	,
				"sv_id"		:	"8901"	,
				"cm_com"	:	"CNT"	,	
				"cm_date"	:	"%d" % cnt
			}
		
	params = urllib.urlencode( POSTLIST ) 
	headers = {"Content-type": "application/x-www-form-urlencoded","Accept": "text/plain"}
	conn = httplib.HTTPConnection("kitagami.org:1234")
	#conn = httplib.HTTPConnection("localhost:1234")
	conn.request("POST", "/post", params, headers)
	response = conn.getresponse()
	print response.status, response.reason
	data = response.read()
	print data
	time.sleep(2)

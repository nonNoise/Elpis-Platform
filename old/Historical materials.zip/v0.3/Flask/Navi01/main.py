# -*- coding: utf-8 -*-
import ElpisDB
import ElpisXML
import datetime
import time
import sys 



inxml = ElpisXML.ElpisXML("conf.xml")
print inxml
inxml.AllRead()
navi = inxml.GetElement("Navi_Input")
dblist_url = inxml.GetAttribute(navi,"DB","url") 
dblist_id = inxml.GetAttribute(navi,"DB","id") 
navi = inxml.GetElement("Navi_Output")
dbout = inxml.GetAttribute(navi,"DB","url") 

#print dblist_url


while 1 :
	timedata = []
	for i in range(len(dblist_id)):
		db = ElpisDB.ElpisDB(dblist_url[i])
		#print db.Get_Table()
		for a in db.Get_Column("Input","time") :
			print a[0]
			pass
		timedata.append(a[0] )
	
	print timedata


	print dblist_id	
	
	dataxml = ElpisXML.ElpisXML("Debug/data.xml")
	test = dataxml.GetElement("TestDATA")
	dataxml.AllRead()
	dataxml.WriteAttribute(test,"id",dblist_id) 
	dataxml.WriteAttribute(test,"data",timedata) 
	dataxml.FileWrite()

	time.sleep(1)
	#print xml.GetAttribute(navi,"DB","id") 



// JavaScript Document

// -------------------------------------------------
// ユーザー設定
// -------------------------------------------------

var refreshRate = 1000;     // リフレッシュスピード設定　単位（ms)

 
// -------------------------------------------------
// 初期設定（いったんHTMLを空にする）
// -------------------------------------------------
$(function(){
    $("table.tbl tbody").html("");
});

// -------------------------------------------------
// XML読み込み
// -------------------------------------------------

function xmlLoad(){
	//$("#block").fadeTo(900,0);  //Jquery　900msかけてアルファチャンネルを０（透明）に。
    $.ajax({
        url:'data.xml',
        type:'get',
        dataType:'xml',
        timeout:1000,
        success:parse_xml
    });
}

// -------------------------------------------------
// XMLデータを取得
// -------------------------------------------------

function parse_xml(xml,status){
    if(status!='success')return;
	$("table.tbl tbody").html(""); //2度目以降の更新時のテーブル初期化。
    $(xml).find('DB').each(getdata);
}

// -------------------------------------------------
// HTML生成関数
// -------------------------------------------------

function getdata(){

    //各要素を変数に格納
    var $id = $(this).attr("id");
    var $data = $(this).attr("data");
    //var $category = $(this).find('category').text();
    //var $content = $(this).find('content').text();
    //var $url = $(this).find('url').text();
    //var $target = $(this).find('target').text();

    //HTMLを生成
    $('<tr>'+
        '<td>'+$id+'</td>'+
        '<td>'+$data+'</td>'+
        '</tr>').appendTo('table.tbl tbody');
}
var xmlLoop = function(){
		xmlLoad();
		//$("#block").fadeTo(10,1); 		//Jquery　10msかけてアルファチャンネルを１に。
		setTimeout("xmlLoop()",refreshRate);	//xmlLoopを内部読み出しすることで繰り返し処理。
		
};
//関数実行
$(function (){
		xmlLoop();
		});
